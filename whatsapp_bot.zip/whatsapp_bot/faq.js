/** 
  *AI GURUKUL FAQ DATA BANK
  *This file contains the keyword mapping and responses for the bot.
 */

const FAQS = [
    {
        id: "1",
        keywords: ["future studies", "career", "study", "logical thinking", "future"],
        question: "Will this help in future studies?",
        answer: "🎓 AI Udaan School\nYes. It builds strong logical thinking, creativity, and problem-solving, which helps in subjects like math, science, and future career choices.\n\n💼 AI Pragati - For the people of college\nYes. It helps you apply AI in business, research, and presentations, giving you an edge in academics and projects.\n\n⚙️ AI Shilp (Engineering)\nAbsolutely. It strengthens your technical foundation, project work, and research capability, helping in higher studies (MTech/MS/AI specialization)."
    },
    {
        id: "2",
        keywords: ["exams", "projects", "useful", "exam", "project"],
        question: "Is AI useful for exams or projects?",
        answer: "🎓 AI Udaan\nYes. You can use AI for:\n• Better understanding concepts\n• Creating school projects\n• Generating ideas and presentations\n\n💼 AI Pragati\nYes. AI helps in:\n• Writing assignments\n• Creating reports & PPTs\n• Case study analysis\n\n⚙️ AI Shilp\nYes. AI is critical for:\n• Final year projects\n• Research work\n• Building real-world applications"
    },
    {
        id: "3",
        keywords: ["learn", "workshop", "syllabus", "content", "topic"],
        question: "What will I learn in this workshop?",
        answer: "🎓 AI Udaan\n• Basics of AI\n• Using AI tools\n• Creating mini projects (chatbot, posters, etc.)\n\n💼 AI Pragati\n• AI for business (marketing, finance, HR)\n• Productivity tools\n• Real business use cases\n\n⚙️ AI Shilp\n• ML, GenAI, Agentic AI\n• Python + AI development\n• Building & deploying AI systems"
    },
    {
        id: "4",
        keywords: ["coding", "knowledge", "code", "programming", "python"],
        question: "Do I need coding knowledge?",
        answer: "🎓 AI Udaan\n❌ No coding required\n\n💼 AI Pragati\n❌ No coding required\n\n⚙️ AI Shilp\nYes. Basic coding (Python preferred), but we guide from fundamentals"
    },
    {
        id: "5",
        keywords: ["practical", "examples", "hands-on", "experience"],
        question: "Will there be practical examples?",
        answer: "🎓 AI Udaan (school): Yes – games, tools, mini projects\n💼 AI Pragati (college): Yes – real business cases, reports, dashboards\n⚙️ AI Shilp (job): Yes – coding, AI models, APIs, deployment\n👉 All programs are hands-on focused"
    },
    {
        id: "6",
        keywords: ["help my career", "placement", "jobs", "future career", "career"],
        question: "How will this help my career?",
        answer: "🎓 AI Udaan (school)\n• Early exposure to future careers\n• Builds confidence and innovation mindset\n\n💼 AI Pragati (college)\n• Makes you AI-enabled professional\n• Improves placement opportunities\n\n⚙️ AI Shilp (job)\nPrepares you for roles like:\n• AI Engineer\n• Data Analyst\n• GenAI Developer"
    },
    {
        id: "7",
        keywords: ["certificate", "certification", "verified"],
        question: "Will I get a certificate?",
        answer: "✅ Yes (for all programs)\n• Issued by The DataTech Labs\n• Industry-recognized\n• Useful for: Resume, College portfolio, Placements"
    },
    {
        id: "8",
        keywords: ["what is ai", "artificial intelligence", "definition", "ai?"],
        question: "What is Artificial Intelligence?",
        answer: "Artificial Intelligence (AI) is the ability of machines to think, learn, and make decisions like humans.\nExamples:\n• Chatbots\n• Recommendation systems\n• Self-driving technology"
    },
    {
        id: "9",
        keywords: ["daily life", "used", "everyday", "real life", "daily"],
        question: "Where is AI used in daily life?",
        answer: "AI is already everywhere:\n📱 Mobile apps (Google, Instagram)\n🎬 YouTube/Netflix recommendations\n🛒 Online shopping\n🗺️ Google Maps navigation\n🏦 Banking fraud detection"
    },
    {
        id: "10",
        keywords: ["difficult", "hard", "easy", "complex"],
        question: "Is AI difficult to learn?",
        answer: "❌ No.\nWith the right guidance, AI is easy and interesting.\nOur programs simplify AI for every level."
    },
    {
        id: "11",
        keywords: ["students learn", "kids", "can students", "child"],
        question: "Can students learn AI?",
        answer: "Yes Absolutely.\nStudents from school to postgraduate level can learn AI.\nPrograms are designed age-wise and level-wise."
    },
    {
        id: "12",
        keywords: ["why is ai important", "important for the future", "why ai", "future importance"],
        question: "Why is AI important for the future?",
        answer: "AI will:\n• Transform every industry\n• Create new job opportunities\n• Automate repetitive work\n• Increase efficiency and innovation\n👉 AI is not optional anymore — it is essential."
    }
];

/** 
  *Returns a clean, numbered menu of FAQs
    */
function getFaqMenu() {
    let menu = "🤖 AI Gurukul Bot Menu\n_Reply with a number or just ask your question:_\n\n";
    FAQS.forEach(faq => {
        menu += `${faq.id}. ${faq.question}\n`;
    });
    return menu;
}

/**
* Scans message for numeric IDs or Keyword matches
*/
function findFaqAnswer(userMessage) {
    const text = userMessage.toLowerCase().trim();

    // 1. Check for number
    const matchedById = FAQS.find(f => f.id === text);
    if (matchedById) return matchedById.answer;

    // 2. Check for keywords
    for (const faq of FAQS) {
        for (const kw of faq.keywords) {
            const regex = new RegExp(`\\b${kw}\\b`, "i");
            if (regex.test(text)) {
                return faq.answer;
            }
        }
    }
    return null;
}

module.exports = {
    getFaqMenu,
    findFaqAnswer
};
