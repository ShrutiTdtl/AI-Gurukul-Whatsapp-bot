const FAQS = [
{
id: "1",
question: "Will this help in future studies?",
answer: `🎓 AI Udaan School
Yes. It builds strong logical thinking, creativity, and problem-solving, which helps in subjects like math, science, and future career choices.

💼 AI Pragati - For the people of college
Yes. It helps you apply AI in business, research, and presentations, giving you an edge in academics and projects.

⚙️ AI Shilp (Engineering)
Absolutely. It strengthens your technical foundation, project work, and research capability, helping in higher studies (MTech/MS/AI specialization).`
},

{
id: "2",
question: "Is AI useful for exams or projects?",
answer: `🎓 AI Udaan
Yes. You can use AI for:
• Better understanding concepts
• Creating school projects
• Generating ideas and presentations

💼 AI Pragati
Yes. AI helps in:
• Writing assignments
• Creating reports & PPTs
• Case study analysis

⚙️ AI Shilp
Yes. AI is critical for:
• Final year projects
• Research work
• Building real-world applications`
},

{
id: "3",
question: "What will I learn in this workshop?",
answer: `🎓 AI Udaan
• Basics of AI
• Using AI tools
• Creating mini projects (chatbot, posters, etc.)

💼 AI Pragati
• AI for business (marketing, finance, HR)
• Productivity tools
• Real business use cases

⚙️ AI Shilp
• ML, GenAI, Agentic AI
• Python + AI development
• Building & deploying AI systems`
},

{
id: "4",
question: "Do I need coding knowledge?",
answer: `🎓 AI Udaan
❌ No coding required

💼 AI Pragati
❌ No coding required

⚙️ AI Shilp
Yes. Basic coding (Python preferred), but we guide from fundamentals`
},

{
id: "5",
question: "Will there be practical examples?",
answer: `🎓 AI Udaan (school)
Yes – games, tools, mini projects

💼 AI Pragati (college)
Yes – real business cases, reports, dashboards

⚙️ AI Shilp (job)
Yes – coding, AI models, APIs, deployment

👉 All programs are hands-on focused`
},

{
id: "6",
question: "How will this help my career?",
answer: `🎓 AI Udaan (school)
• Early exposure to future careers
• Builds confidence and innovation mindset

💼 AI Pragati (college)
• Makes you AI-enabled professional
• Improves placement opportunities

⚙️ AI Shilp (job)
Prepares you for roles like:
• AI Engineer
• Data Analyst
• GenAI Developer`
},

{
id: "7",
question: "Will I get a certificate?",
answer: `✅ Yes (for all programs)
• Issued by The DataTech Labs
• Industry-recognized
• Useful for:
  - Resume
  - College portfolio
  - Placements`
},

{
id: "8",
question: "What is this AI workshop about?",
answer: `🎓 AI Udaan (School)
Learning AI in a simple, fun, and practical way

💼 AI Pragati (college)
Using AI to solve business problems and improve productivity

⚙️ AI Shilp (job)
Building real AI systems and applications`
},

{
id: "9",
question: "What is Artificial Intelligence?",
answer: `Artificial Intelligence (AI) is the ability of machines to think, learn, and make decisions like humans.

Examples:
• Chatbots
• Recommendation systems
• Self-driving technology`
},

{
id: "10",
question: "Where is AI used in daily life?",
answer: `AI is already everywhere:
📱 Mobile apps (Google, Instagram)
🎬 YouTube/Netflix recommendations
🛒 Online shopping
🗺️ Google Maps navigation
🏦 Banking fraud detection`
},

{
id: "11",
question: "Is AI difficult to learn?",
answer: `❌ No.
With the right guidance, AI is easy and interesting.
Our programs simplify AI for every level`
},

{
id: "12",
question: "Can students learn AI?",
answer: `Yes absolutely.
Students from school to postgraduate level can learn AI.
Programs are designed age-wise and level-wise`
},

{
id: "13",
question: "Why is AI important for the future?",
answer: `AI will:
• Transform every industry
• Create new job opportunities
• Automate repetitive work
• Increase efficiency and innovation

👉 AI is not optional anymore — it is essential`
}
];

module.exports = { FAQS };