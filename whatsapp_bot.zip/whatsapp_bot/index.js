require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { findFaqAnswer, getFaqMenu, FAQS } = require('./faq');
const app = express();

// ✅ CORS Fix: Allow requests from React dev server (and the live domain)
app.use(cors({
    origin: ['http://localhost:3000', 'http://localhost:5173', 'https://tdtlworld.com','https://aigurukul.tdtl.world/'],
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());
// Serve the Chatbot UI
app.use(express.static(path.join(__dirname, 'public')));

// API for Chatbot
app.post('/api/chat', (req, res) => {
    const { message } = req.body;
    const msg = message.toLowerCase().trim();

    // ✅ If user sends empty → show menu
    if (!msg) {
        return res.json({ answer: getFaqMenu() });
    }

    // ✅ If user sends number (menu selection)
    const selected = FAQS.find(faq => faq.id === msg);
    if (selected) {
        return res.json({ answer: selected.answer });
    }

    // ✅ Otherwise → FAQ matching
    let answer = findFaqAnswer(message);

    if (!answer) {
        // 👉 fallback → show menu again
        answer = getFaqMenu();
    }

    res.json({ answer });
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`\n=========================================`);
    console.log(`🚀 AI GURUKUL WEB-BOT IS LIVE!`);
    console.log(`=========================================`);
    console.log(`\n👉 OPEN THIS URL: http://localhost:${PORT}`);
    console.log(`\nNO QR CODES, NO PAIRING CODES, NO META.`);
    console.log(`THIS BOT WORKS ENTIRELY THROUGH THE LINK.`);
    console.log(`=========================================\n`);
});
