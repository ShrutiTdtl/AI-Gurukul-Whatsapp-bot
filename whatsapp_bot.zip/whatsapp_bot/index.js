require('dotenv').config();
const express = require('express');
const path = require('path');
const { findFaqAnswer } = require('./faq');
const app = express();

app.use(express.json());
// Serve the Chatbot UI
app.use(express.static(path.join(__dirname, 'public')));

// API for Chatbot
app.post('/api/chat', (req, res) => {
    const { message } = req.body;
    const msg = message.toLowerCase().trim();

    // Check for greetings
    const greetings = ['hi', 'hello', 'hey', 'hii', 'hy'];
    if (greetings.includes(msg)) {
        const hour = new Date().getHours();
        let timeGreeting = "Good Evening";

        if (hour >= 5 && hour < 12) timeGreeting = "Good Morning";
        else if (hour >= 12 && hour < 18) timeGreeting = "Good Afternoon";

        return res.json({
            answer: `👋 ${timeGreeting}!Welcome to AI Gurukul. How can I help you today? You can ask about our courses, certification, or future studies!`
        });
    }

    let answer = findFaqAnswer(message);

    if (!answer) {
        answer = "That's a great question!I'm still learning about that, but it sounds very interesting. You might want to ask one of our teachers directly for a detailed answer! 👇";
    }

    res.json({ answer });
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`\n=========================================`);
    console.log(`🚀 AI GURUKUL WEB-BOT IS LIVE!`);
    console.log(`=========================================`);
    console.log(`\n👉 OPEN THIS URL: http://localhost:${PORT}`);
    console.log(`\nNO QR CODES, NO PAIRING CODES, NO META.`);
    console.log(`THIS BOT WORKS ENTIRELY THROUGH THE LINK.`);
    console.log(`=========================================\n`);
});
